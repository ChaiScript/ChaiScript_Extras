2.0-2
-----
* guaranteed support for more compilers
* improved CMakeLists.txt

2.0-1
-----
* updated support for newer Biicode versions
* improved CMakeLists.txt
* compatibility mode to support MSVC

2.0
---
* added interface base class for databases
* allows implementing custom databases and different types for each string_id
* added methods for generating string identifiers
* internal changes in database implementation for performance improvements
* support for non-Biicode builds

1.1
---
* removed global database to allow multiple
* added option to enable non-threadsafe database
* improved CMakeLists.txt

1.0
---
* initial state
